function pat(){
    let n = document.getElementById("nom").value
    p = n * n
    // le nombre au carré est le nombre multiplié par lui même
     x = '<p> Le carré est : '+p+'</p>'
     document.body.innerHTML = x

 
 } 