function pat(){
    let n = document.getElementById("nom").value
    p = 2020 - n
     x = '<p> votre age est : '+p+'</p>'
     document.body.innerHTML = x
     console.log(x)
 
 } 